const express = require('express');
const app = express();
const PORT = 8080;
const HOST = 'localhost';

// Serve static files from the public directory
app.use(express.static('public'));

// Import functions from p3-module.js
const { coinCombo, coinValue } = require('./p3-module');

// GET route for /coincombo
app.get('/coincombo', (req, res) => {
  const amount = Number(req.query.amount);
  if (isNaN(amount) || amount < 0) {
    return res.json({ error: 'Amount must be a non-negative number' });
  }
  const result = coinCombo(amount);
  res.json(result);
});

// GET route for /coinvalue
app.get('/coinvalue', (req, res) => {
  const {
    pennies = 0,
    nickels = 0,
    dimes = 0,
    quarters = 0,
    halves = 0,
    dollars = 0,
  } = req.query;

  const coinCounts = {
    pennies: parseInt(pennies) || 0,
    nickels: parseInt(nickels) || 0,
    dimes: parseInt(dimes) || 0,
    quarters: parseInt(quarters) || 0,
    halves: parseInt(halves) || 0,
    dollars: parseInt(dollars) || 0,
  };

  const result = coinValue(coinCounts);
  res.json(result);
});

// 404 handler
app.use((req, res) => {
  res.status(404).send('404 Not Found');
});

// Start the server
app.listen(PORT, HOST, () => {
  console.log(`Server is running at http://${HOST}:${PORT}/`);
});
